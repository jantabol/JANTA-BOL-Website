const menuBtn = document.querySelector(".menu-btn");
const sideMenu = document.querySelector(".side-menu");
const closeMenu = document.querySelector(".close-menu");
const overlay = document.querySelector(".menu-overlay");
menuBtn.addEventListener("click", () => {

    sideMenu.style.right = "0";

    overlay.style.opacity = "1";
    overlay.style.visibility = "visible";

    document.body.style.overflow = "hidden";

});
closeMenu.addEventListener("click", () => {

    sideMenu.style.right = "-70%";

    overlay.style.opacity = "0";
    overlay.style.visibility = "hidden";

    document.body.style.overflow = "auto";

});
overlay.addEventListener("click", () => {

    sideMenu.style.right = "-70%";

    overlay.style.opacity = "0";
    overlay.style.visibility = "hidden";

    document.body.style.overflow = "auto";

});
// Close menu with ESC key
document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {

        sideMenu.style.right = "-70%";

        overlay.style.opacity = "0";
        overlay.style.visibility = "hidden";

        document.body.style.overflow = "auto";
    }
});
// Close menu when any menu link is clicked
document.querySelectorAll(".side-menu a").forEach(link => {
    link.addEventListener("click", () => {
        sideMenu.style.right = "-70%";

        overlay.style.opacity = "0";
        overlay.style.visibility = "hidden";

        document.body.style.overflow = "auto";
    });
});
// Dropdown Menu

document.querySelectorAll(".menu-toggle").forEach(button => {
    button.addEventListener("click", function (e) {
        e.stopPropagation();

        const parent = this.parentElement;

        document.querySelectorAll(".menu-group").forEach(group => {
            if (group !== parent) {
                group.classList.remove("active");
            }
        });

        parent.classList.toggle("active");
    });
});

document.addEventListener("click", () => {
    document.querySelectorAll(".menu-group").forEach(group => {
        group.classList.remove("active");
    });
});